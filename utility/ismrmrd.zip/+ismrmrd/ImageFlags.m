% IMAGE FLAGS %
classdef ImageFlags
    properties(Constant)
        IMAGE_IS_NAVIGATION_DATA      				= 23,
        IMAGE_USER1                   				= 57,
        IMAGE_USER2                   				= 58,
        IMAGE_USER3                   				= 59,
        IMAGE_USER4                   				= 60,
        IMAGE_USER5                   				= 61,
        IMAGE_USER6                   				= 62,
        IMAGE_USER7                   				= 63,
        IMAGE_USER8                   				= 64
    end
end