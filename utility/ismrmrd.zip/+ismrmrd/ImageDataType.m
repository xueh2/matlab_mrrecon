classdef ImageDataType
    properties(Constant)
        DATA_FLOAT = 1,
        DATA_DOUBLE = 2,
        DATA_COMPLEX_FLOAT = 3,
        DATA_COMPLEX_DOUBLE = 4,
        DATA_UNSIGNED_SHORT = 5
    end
end
