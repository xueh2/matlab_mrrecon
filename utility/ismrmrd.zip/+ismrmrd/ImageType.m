classdef ImageType
    properties(Constant)
        TYPE_MAGNITUDE = 1,
        TYPE_PHASE = 2,
        TYPE_REAL = 3,
        TYPE_IMAG = 4,
        TYPE_COMPLEX = 5
    end
end
