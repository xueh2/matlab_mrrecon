function out = ndims(fa)
% Number of dimensions
%_______________________________________________________________________
% Copyright (C) 2005 Wellcome Department of Imaging Neuroscience

%
% $Id: ndims.m 253 2005-10-13 15:31:34Z guillaume $


out = size(fa);
out = length(out);

