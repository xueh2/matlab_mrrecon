function varargout = cpermute(varargin)
% Permuting is not allowed
% _______________________________________________________________________
% Copyright (C) 2005 Wellcome Department of Imaging Neuroscience

%
% $Id: cpermute.m 253 2005-10-13 15:31:34Z guillaume $

error('file_array objects can not be permuted.');
