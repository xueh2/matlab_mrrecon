function display(obj)
% Display a NIFTI-1 object
% _______________________________________________________________________
% Copyright (C) 2005 Wellcome Department of Imaging Neuroscience

%
% $Id: display.m 253 2005-10-13 15:31:34Z guillaume $


disp(' ');
disp([inputname(1),' = '])
disp(' ');
disp(obj)
disp(' ')
